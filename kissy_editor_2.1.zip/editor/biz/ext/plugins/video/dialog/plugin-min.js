KISSY.Editor.add("video/dialog",function(a){var b=KISSY.Editor;b.use("video/dialog/support",function(){a.addDialog("video/dialog",new b.Video.Dialog(a))})});
