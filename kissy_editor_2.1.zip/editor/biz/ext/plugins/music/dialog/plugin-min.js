KISSY.Editor.add("xiami-music/dialog",function(a){var b=KISSY.Editor;b.use("xiami-music/dialog/support",function(){a.addDialog("xiami-music/dialog",new b.XiamiMusic.Dialog(a))})});
