KISSY.Editor.add("bangpai-music/dialog",function(a){var b=KISSY.Editor;b.use("bangpai-music/dialog/support",function(){a.addDialog("bangpai-music/dialog",new b.BangPaiMusic.Dialog(a))})});
