KISSY.Editor.add("bangpai-video/dialog",function(a){var b=KISSY.Editor;b.use("bangpai-video/dialog/support",function(){a.addDialog("bangpai-video/dialog",new b.BangPaiVideo.Dialog(a))})});
