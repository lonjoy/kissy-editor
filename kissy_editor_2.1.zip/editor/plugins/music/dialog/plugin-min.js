KISSY.Editor.add("music/dialog",function(a){var b=KISSY.Editor;b.use("music/dialog/support",function(){a.addDialog("music/dialog",new b.MusicInserter.Dialog(a))})},{attach:false});
