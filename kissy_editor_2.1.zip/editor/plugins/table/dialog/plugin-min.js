KISSY.Editor.add("table/dialog",function(a){var b=KISSY.Editor;b.use("table/dialog/support",function(){a.addDialog("table/dialog",new b.TableUI.Dialog(a))})},{attach:false});
