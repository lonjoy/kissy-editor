/**
 * dumb ,告诉 editor ，其dd已经loaded，否则会动态请求
 * 桥 kissy dd ->  editor dd
 */
KISSY.Editor.add("dd", function() {
});