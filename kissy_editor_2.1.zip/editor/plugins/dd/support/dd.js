KISSY.Editor.add("dd", function() {
});