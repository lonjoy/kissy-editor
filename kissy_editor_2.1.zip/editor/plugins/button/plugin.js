/**
 * triple state button for kissy editor
 * @author: yiminghe@gmail.com
 */
KISSY.Editor.add("button", function(editor) {
    var KE = KISSY.Editor,
        S = KISSY,
        ON = "on",
        OFF = "off",
        DISABLED = "disabled",
        Node = S.Node,
        BUTTON_CLASS = "ke-triplebutton",
        ON_CLASS = "ke-triplebutton-on",
        OFF_CLASS = "ke-triplebutton-off",
        ACTIVE_CLASS = "ke-triplebutton-active",
        DISABLED_CLASS = "ke-triplebutton-disabled",
        BUTTON_HTML = "<a class='" +
            [BUTTON_CLASS,OFF_CLASS].join(" ")
            + "' href='#'" +
            "" +
            //' tabindex="-1"' +
            //' hidefocus="true"' +
            ' role="button"' +
            //' onblur="this.style.cssText = this.style.cssText;"' +
            //' onfocus="event&&event.preventBubble();return false;"' +
            "></a>";
    if (KE.TripleButton) return;

    function TripleButton(cfg) {
        TripleButton.superclass.constructor.call(this, cfg);
        this._init();
    }

    TripleButton.ON = ON;
    TripleButton.OFF = OFF;
    TripleButton.DISABLED = DISABLED;

    TripleButton.ON_CLASS = ON_CLASS;
    TripleButton.OFF_CLASS = OFF_CLASS;
    TripleButton.DISABLED_CLASS = DISABLED_CLASS;

    TripleButton.ATTRS = {
        state: {value:OFF},
        container:{},
        text:{},
        contentCls:{},
        cls:{},
        el:{}
    };


    S.extend(TripleButton, S.Base, {
        _init:function() {
            var self = this,
                container = self.get("container"),
                elHolder = self.get("el"),
                title = self.get("title"),
                text = self.get("text"),
                contentCls = self.get("contentCls");
            self.el = new Node(BUTTON_HTML);
            var el = self.el;
            el._4e_unselectable();
            self._attachCls();
            //button有文子
            if (text) {
                el.html(text);
                //直接上图标
            } else if (contentCls) {
                el.html("<span class='ke-toolbar-item " +
                    contentCls + "'></span>");
                el.one("span")._4e_unselectable();
            }
            if (title) el.attr("title", title);
            //替换已有元素
            if (elHolder) {
                elHolder[0].parentNode.replaceChild(el[0], elHolder[0]);
            }
            //加入容器
            else if (container) {
                container.append(el);
            }
            el.on("click", self._action, self);
            self.on("afterStateChange", self._stateChange, self);


            if (!self.get("cls")) {
                //添加鼠标点击视觉效果
                el.on("mousedown", function() {
                    if (self.get("state") == OFF) {
                        el.addClass(ACTIVE_CLASS);
                    }
                });
                el.on("mouseup mouseleave", function() {
                    if (self.get("state") == OFF &&
                        el.hasClass(ACTIVE_CLASS)) {
                        //click 后出发
                        setTimeout(function() {
                            el.removeClass(ACTIVE_CLASS);
                        }, 300);
                    }
                });
            }
        },
        _attachCls:function() {
            var self = this;
            var cls = self.get("cls");
            if (cls) self.el.addClass(cls);
        },

        _stateChange:function(ev) {
            var n = ev.newVal,self = this;
            self["_" + n]();
            self._attachCls();
        },
        disable:function() {
            var self = this;
            self._savedState = self.get("state");
            self.set("state", DISABLED);
        },
        enable:function() {
            var self = this;
            if (self.get("state") == DISABLED)
                self.set("state", self._savedState);
        },
        _action:function(ev) {
            var self = this;
            self.fire(self.get("state") + "Click", ev);
            self.fire("click", ev);
            ev.preventDefault();
        },
        bon:function() {
            this.set("state", ON);
        },
        boff:function() {
            this.set("state", OFF);
        },
        _on:function() {
            this.el[0].className = [BUTTON_CLASS,ON_CLASS].join(" ");
        },
        _off:function() {
            this.el[0].className = [BUTTON_CLASS,OFF_CLASS].join(" ");
        },
        _disabled:function() {
            this.el[0].className = [BUTTON_CLASS,DISABLED_CLASS].join(" ");
        }
    });
    KE.TripleButton = TripleButton;
});
