KISSY.Editor.add("flash/dialog",function(a){var b=KISSY.Editor;b.use("flash/dialog/support",function(){a.addDialog("flash/dialog",new b.Flash.FlashDialog(a))})},{attach:false});
